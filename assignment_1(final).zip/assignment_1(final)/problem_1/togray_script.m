im_togray('ted.jpg');
im_togray('study.jpg');
im_togray('Lena.jpg');