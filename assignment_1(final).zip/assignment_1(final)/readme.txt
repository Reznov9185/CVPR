

1. Each problem folder contain all the codes, images and script files. 

2. Run the ".*script.m" files in each folder to do the things we are asked 
   to do in that current problem.

3. Each fuctions are written to perform their desired tasks

Thanks you :)

Submitted by: Sajid & Ummoy. 