figure('units','normalized','outerposition',[0 0 1 1]) %fullscreen the figure
subplot(1,2,1),imshow(EdgeDetector('Lenna.png')); %shows dark segment
title('Edge detection using SOBEL'); 
subplot(1,2,2),imshow(CannyEdgeDetection('Lenna.png',150,120)); %shows light segment
title('Canny edge detection');